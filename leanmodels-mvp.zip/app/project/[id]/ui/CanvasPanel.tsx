'use client';
import { useState } from 'react';

const DEFAULT_SECTIONS = [
  { key:'customer_segments', title:'顧客セグメント' },
  { key:'problem', title:'課題' },
  { key:'unique_value', title:'独自の価値提案' },
  { key:'solution', title:'ソリューション' },
  { key:'channels', title:'チャネル' },
  { key:'revenue', title:'収益の流れ' },
  { key:'cost', title:'コスト構造' },
  { key:'metrics', title:'主要指標' },
  { key:'advantage', title:'圧倒的優位性' },
];

export default function CanvasPanel({ projectId }: { projectId: string }) {
  const [sections] = useState(DEFAULT_SECTIONS);

  return (
    <div className="p-6 space-y-6">
      {sections.map((s, i) => (
        <div key={s.key} className="bg-white rounded-lg border p-5 shadow-sm">
          <header className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">{i+1}. {s.title}</h2>
            <div className="text-sm text-gray-500">AIと同期</div>
          </header>
          <SectionItems sectionKey={s.key}/>
        </div>
      ))}
    </div>
  );
}

function SectionItems({ sectionKey }: { sectionKey: string }) {
  const [items, setItems] = useState<string[]>(['']);

  return (
    <div className="space-y-2">
      {items.map((v, idx) => (
        <div key={idx} className="group relative">
          <textarea
            className="w-full resize-y rounded border px-3 py-2 text-sm focus:outline-none focus:ring-1"
            rows={3}
            value={v}
            onChange={(e)=> {
              const next=[...items]; next[idx]=e.target.value; setItems(next);
            }}
            placeholder="箇条書きで入力…"
          />
          <HoverHint text="例：都市部の20〜40代ビジネスパーソン／効率重視／アプリ利用率が高い" />
        </div>
      ))}
      <button
        className="text-sm underline"
        onClick={()=> setItems([...items, ''])}
      >+ 追加</button>
    </div>
  );
}

function HoverHint({ text }: { text: string }) {
  return (
    <div className="absolute -right-1 top-2 translate-x-full">
      <div className="relative">
        <span className="text-xs text-gray-400">ⓘ</span>
        <div className="invisible group-hover:visible absolute left-4 top-0 w-64 rounded border bg-white p-3 text-xs shadow">
          {text}
        </div>
      </div>
    </div>
  );
}
